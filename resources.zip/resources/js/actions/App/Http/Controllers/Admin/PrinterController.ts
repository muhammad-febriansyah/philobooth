import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PrinterController::index
* @see app/Http/Controllers/Admin/PrinterController.php:21
* @route '/admin/printer'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/printer',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PrinterController::index
* @see app/Http/Controllers/Admin/PrinterController.php:21
* @route '/admin/printer'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PrinterController::index
* @see app/Http/Controllers/Admin/PrinterController.php:21
* @route '/admin/printer'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::index
* @see app/Http/Controllers/Admin/PrinterController.php:21
* @route '/admin/printer'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::index
* @see app/Http/Controllers/Admin/PrinterController.php:21
* @route '/admin/printer'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::index
* @see app/Http/Controllers/Admin/PrinterController.php:21
* @route '/admin/printer'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::index
* @see app/Http/Controllers/Admin/PrinterController.php:21
* @route '/admin/printer'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\PrinterController::store
* @see app/Http/Controllers/Admin/PrinterController.php:95
* @route '/admin/printer'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/printer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PrinterController::store
* @see app/Http/Controllers/Admin/PrinterController.php:95
* @route '/admin/printer'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PrinterController::store
* @see app/Http/Controllers/Admin/PrinterController.php:95
* @route '/admin/printer'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::store
* @see app/Http/Controllers/Admin/PrinterController.php:95
* @route '/admin/printer'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::store
* @see app/Http/Controllers/Admin/PrinterController.php:95
* @route '/admin/printer'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\PrinterController::pingAll
* @see app/Http/Controllers/Admin/PrinterController.php:205
* @route '/admin/printer/ping-all'
*/
export const pingAll = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pingAll.url(options),
    method: 'post',
})

pingAll.definition = {
    methods: ["post"],
    url: '/admin/printer/ping-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PrinterController::pingAll
* @see app/Http/Controllers/Admin/PrinterController.php:205
* @route '/admin/printer/ping-all'
*/
pingAll.url = (options?: RouteQueryOptions) => {
    return pingAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PrinterController::pingAll
* @see app/Http/Controllers/Admin/PrinterController.php:205
* @route '/admin/printer/ping-all'
*/
pingAll.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pingAll.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::pingAll
* @see app/Http/Controllers/Admin/PrinterController.php:205
* @route '/admin/printer/ping-all'
*/
const pingAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pingAll.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::pingAll
* @see app/Http/Controllers/Admin/PrinterController.php:205
* @route '/admin/printer/ping-all'
*/
pingAllForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pingAll.url(options),
    method: 'post',
})

pingAll.form = pingAllForm

/**
* @see \App\Http\Controllers\Admin\PrinterController::ping
* @see app/Http/Controllers/Admin/PrinterController.php:184
* @route '/admin/printer/{printer}/ping'
*/
export const ping = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ping.url(args, options),
    method: 'post',
})

ping.definition = {
    methods: ["post"],
    url: '/admin/printer/{printer}/ping',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PrinterController::ping
* @see app/Http/Controllers/Admin/PrinterController.php:184
* @route '/admin/printer/{printer}/ping'
*/
ping.url = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { printer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { printer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            printer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        printer: typeof args.printer === 'object'
        ? args.printer.id
        : args.printer,
    }

    return ping.definition.url
            .replace('{printer}', parsedArgs.printer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PrinterController::ping
* @see app/Http/Controllers/Admin/PrinterController.php:184
* @route '/admin/printer/{printer}/ping'
*/
ping.post = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ping.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::ping
* @see app/Http/Controllers/Admin/PrinterController.php:184
* @route '/admin/printer/{printer}/ping'
*/
const pingForm = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ping.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::ping
* @see app/Http/Controllers/Admin/PrinterController.php:184
* @route '/admin/printer/{printer}/ping'
*/
pingForm.post = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ping.url(args, options),
    method: 'post',
})

ping.form = pingForm

/**
* @see \App\Http\Controllers\Admin\PrinterController::activate
* @see app/Http/Controllers/Admin/PrinterController.php:191
* @route '/admin/printer/{printer}/activate'
*/
export const activate = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activate.url(args, options),
    method: 'post',
})

activate.definition = {
    methods: ["post"],
    url: '/admin/printer/{printer}/activate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PrinterController::activate
* @see app/Http/Controllers/Admin/PrinterController.php:191
* @route '/admin/printer/{printer}/activate'
*/
activate.url = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { printer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { printer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            printer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        printer: typeof args.printer === 'object'
        ? args.printer.id
        : args.printer,
    }

    return activate.definition.url
            .replace('{printer}', parsedArgs.printer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PrinterController::activate
* @see app/Http/Controllers/Admin/PrinterController.php:191
* @route '/admin/printer/{printer}/activate'
*/
activate.post = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: activate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::activate
* @see app/Http/Controllers/Admin/PrinterController.php:191
* @route '/admin/printer/{printer}/activate'
*/
const activateForm = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: activate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::activate
* @see app/Http/Controllers/Admin/PrinterController.php:191
* @route '/admin/printer/{printer}/activate'
*/
activateForm.post = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: activate.url(args, options),
    method: 'post',
})

activate.form = activateForm

/**
* @see \App\Http\Controllers\Admin\PrinterController::refillPaper
* @see app/Http/Controllers/Admin/PrinterController.php:218
* @route '/admin/printer/{printer}/refill'
*/
export const refillPaper = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refillPaper.url(args, options),
    method: 'post',
})

refillPaper.definition = {
    methods: ["post"],
    url: '/admin/printer/{printer}/refill',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PrinterController::refillPaper
* @see app/Http/Controllers/Admin/PrinterController.php:218
* @route '/admin/printer/{printer}/refill'
*/
refillPaper.url = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { printer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { printer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            printer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        printer: typeof args.printer === 'object'
        ? args.printer.id
        : args.printer,
    }

    return refillPaper.definition.url
            .replace('{printer}', parsedArgs.printer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PrinterController::refillPaper
* @see app/Http/Controllers/Admin/PrinterController.php:218
* @route '/admin/printer/{printer}/refill'
*/
refillPaper.post = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refillPaper.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::refillPaper
* @see app/Http/Controllers/Admin/PrinterController.php:218
* @route '/admin/printer/{printer}/refill'
*/
const refillPaperForm = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: refillPaper.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::refillPaper
* @see app/Http/Controllers/Admin/PrinterController.php:218
* @route '/admin/printer/{printer}/refill'
*/
refillPaperForm.post = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: refillPaper.url(args, options),
    method: 'post',
})

refillPaper.form = refillPaperForm

/**
* @see \App\Http\Controllers\Admin\PrinterController::update
* @see app/Http/Controllers/Admin/PrinterController.php:139
* @route '/admin/printer/{printer}'
*/
export const update = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/printer/{printer}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\PrinterController::update
* @see app/Http/Controllers/Admin/PrinterController.php:139
* @route '/admin/printer/{printer}'
*/
update.url = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { printer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { printer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            printer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        printer: typeof args.printer === 'object'
        ? args.printer.id
        : args.printer,
    }

    return update.definition.url
            .replace('{printer}', parsedArgs.printer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PrinterController::update
* @see app/Http/Controllers/Admin/PrinterController.php:139
* @route '/admin/printer/{printer}'
*/
update.put = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::update
* @see app/Http/Controllers/Admin/PrinterController.php:139
* @route '/admin/printer/{printer}'
*/
const updateForm = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::update
* @see app/Http/Controllers/Admin/PrinterController.php:139
* @route '/admin/printer/{printer}'
*/
updateForm.put = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\PrinterController::destroy
* @see app/Http/Controllers/Admin/PrinterController.php:177
* @route '/admin/printer/{printer}'
*/
export const destroy = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/printer/{printer}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\PrinterController::destroy
* @see app/Http/Controllers/Admin/PrinterController.php:177
* @route '/admin/printer/{printer}'
*/
destroy.url = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { printer: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { printer: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            printer: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        printer: typeof args.printer === 'object'
        ? args.printer.id
        : args.printer,
    }

    return destroy.definition.url
            .replace('{printer}', parsedArgs.printer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PrinterController::destroy
* @see app/Http/Controllers/Admin/PrinterController.php:177
* @route '/admin/printer/{printer}'
*/
destroy.delete = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::destroy
* @see app/Http/Controllers/Admin/PrinterController.php:177
* @route '/admin/printer/{printer}'
*/
const destroyForm = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PrinterController::destroy
* @see app/Http/Controllers/Admin/PrinterController.php:177
* @route '/admin/printer/{printer}'
*/
destroyForm.delete = (args: { printer: number | { id: number } } | [printer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const PrinterController = { index, store, pingAll, ping, activate, refillPaper, update, destroy }

export default PrinterController
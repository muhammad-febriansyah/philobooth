import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/transaksi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportPdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
export const exportPdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})

exportPdf.definition = {
    methods: ["get","head"],
    url: '/admin/transaksi/export/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportPdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
exportPdf.url = (options?: RouteQueryOptions) => {
    return exportPdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportPdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
exportPdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportPdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
exportPdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportPdf.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportPdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
const exportPdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportPdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
exportPdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportPdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
exportPdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportPdf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportPdf.form = exportPdfForm

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportCsv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
export const exportCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})

exportCsv.definition = {
    methods: ["get","head"],
    url: '/admin/transaksi/export/csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportCsv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
exportCsv.url = (options?: RouteQueryOptions) => {
    return exportCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportCsv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
exportCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportCsv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
exportCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportCsv.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportCsv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
const exportCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportCsv.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportCsv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
exportCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportCsv.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::exportCsv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
exportCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exportCsv.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exportCsv.form = exportCsvForm

const TransaksiController = { index, exportPdf, exportCsv }

export default TransaksiController
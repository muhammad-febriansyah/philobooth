import CabangController from './CabangController'
import SettingsController from './SettingsController'
import UserController from './UserController'
import GlobalSearchController from './GlobalSearchController'
import AgentController from './AgentController'
import VoucherController from './VoucherController'
import PrinterController from './PrinterController'
import FrameController from './FrameController'
import TransaksiController from './TransaksiController'

const Admin = {
    CabangController: Object.assign(CabangController, CabangController),
    SettingsController: Object.assign(SettingsController, SettingsController),
    UserController: Object.assign(UserController, UserController),
    GlobalSearchController: Object.assign(GlobalSearchController, GlobalSearchController),
    AgentController: Object.assign(AgentController, AgentController),
    VoucherController: Object.assign(VoucherController, VoucherController),
    PrinterController: Object.assign(PrinterController, PrinterController),
    FrameController: Object.assign(FrameController, FrameController),
    TransaksiController: Object.assign(TransaksiController, TransaksiController),
}

export default Admin
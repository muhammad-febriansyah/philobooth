import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
const DokuNotifyController = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: DokuNotifyController.url(options),
    method: 'post',
})

DokuNotifyController.definition = {
    methods: ["post"],
    url: '/api/booth/payment/callback',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
DokuNotifyController.url = (options?: RouteQueryOptions) => {
    return DokuNotifyController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
DokuNotifyController.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: DokuNotifyController.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
const DokuNotifyControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: DokuNotifyController.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
DokuNotifyControllerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: DokuNotifyController.url(options),
    method: 'post',
})

DokuNotifyController.form = DokuNotifyControllerForm

export default DokuNotifyController
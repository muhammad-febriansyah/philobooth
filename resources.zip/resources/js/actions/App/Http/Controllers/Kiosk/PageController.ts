import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
export const welcome = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: welcome.url(options),
    method: 'get',
})

welcome.definition = {
    methods: ["get","head"],
    url: '/kiosk/welcome',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcome.url = (options?: RouteQueryOptions) => {
    return welcome.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcome.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: welcome.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcome.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: welcome.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
const welcomeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcome.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcomeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcome.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcomeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcome.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

welcome.form = welcomeForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
export const welcomeDark = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: welcomeDark.url(options),
    method: 'get',
})

welcomeDark.definition = {
    methods: ["get","head"],
    url: '/kiosk/welcome-dark',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDark.url = (options?: RouteQueryOptions) => {
    return welcomeDark.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDark.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: welcomeDark.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDark.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: welcomeDark.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
const welcomeDarkForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcomeDark.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDarkForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcomeDark.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDarkForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcomeDark.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

welcomeDark.form = welcomeDarkForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
export const payment = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payment.url(options),
    method: 'get',
})

payment.definition = {
    methods: ["get","head"],
    url: '/kiosk/payment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
payment.url = (options?: RouteQueryOptions) => {
    return payment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
payment.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
payment.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: payment.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
const paymentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
paymentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
paymentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

payment.form = paymentForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
export const qris = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qris.url(options),
    method: 'get',
})

qris.definition = {
    methods: ["get","head"],
    url: '/kiosk/qris',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qris.url = (options?: RouteQueryOptions) => {
    return qris.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qris.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qris.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qris.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qris.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
const qrisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qris.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qrisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qris.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qrisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qris.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

qris.form = qrisForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
export const voucher = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: voucher.url(options),
    method: 'get',
})

voucher.definition = {
    methods: ["get","head"],
    url: '/kiosk/voucher',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucher.url = (options?: RouteQueryOptions) => {
    return voucher.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucher.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: voucher.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucher.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: voucher.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
const voucherForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucherForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucherForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

voucher.form = voucherForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::validatePay
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
export const validatePay = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: validatePay.url(options),
    method: 'get',
})

validatePay.definition = {
    methods: ["get","head"],
    url: '/kiosk/validate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::validatePay
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validatePay.url = (options?: RouteQueryOptions) => {
    return validatePay.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::validatePay
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validatePay.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: validatePay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::validatePay
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validatePay.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: validatePay.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::validatePay
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
const validatePayForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: validatePay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::validatePay
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validatePayForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: validatePay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::validatePay
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validatePayForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: validatePay.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

validatePay.form = validatePayForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
export const frameSelect = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: frameSelect.url(options),
    method: 'get',
})

frameSelect.definition = {
    methods: ["get","head"],
    url: '/kiosk/frame-select',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelect.url = (options?: RouteQueryOptions) => {
    return frameSelect.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelect.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: frameSelect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelect.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: frameSelect.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
const frameSelectForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameSelect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelectForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameSelect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelectForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameSelect.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

frameSelect.form = frameSelectForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
export const capture = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: capture.url(options),
    method: 'get',
})

capture.definition = {
    methods: ["get","head"],
    url: '/kiosk/capture',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
capture.url = (options?: RouteQueryOptions) => {
    return capture.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
capture.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: capture.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
capture.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: capture.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
const captureForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: capture.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
captureForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: capture.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
captureForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: capture.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

capture.form = captureForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
export const preview = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/kiosk/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
preview.url = (options?: RouteQueryOptions) => {
    return preview.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
preview.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
preview.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
const previewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
previewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
previewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

preview.form = previewForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
export const filter = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filter.url(options),
    method: 'get',
})

filter.definition = {
    methods: ["get","head"],
    url: '/kiosk/filter',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filter.url = (options?: RouteQueryOptions) => {
    return filter.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filter.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filter.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: filter.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
const filterForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filterForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filterForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

filter.form = filterForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
export const qty = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qty.url(options),
    method: 'get',
})

qty.definition = {
    methods: ["get","head"],
    url: '/kiosk/qty',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qty.url = (options?: RouteQueryOptions) => {
    return qty.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qty.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qty.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qty.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qty.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
const qtyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qty.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qtyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qty.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qtyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qty.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

qty.form = qtyForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
export const confirm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirm.url(options),
    method: 'get',
})

confirm.definition = {
    methods: ["get","head"],
    url: '/kiosk/confirm',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirm.url = (options?: RouteQueryOptions) => {
    return confirm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: confirm.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
const confirmForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirmForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirmForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

confirm.form = confirmForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
export const extraPay = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: extraPay.url(options),
    method: 'get',
})

extraPay.definition = {
    methods: ["get","head"],
    url: '/kiosk/extra-pay',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPay.url = (options?: RouteQueryOptions) => {
    return extraPay.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPay.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: extraPay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPay.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: extraPay.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
const extraPayForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: extraPay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPayForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: extraPay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPayForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: extraPay.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

extraPay.form = extraPayForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
export const printing = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printing.url(options),
    method: 'get',
})

printing.definition = {
    methods: ["get","head"],
    url: '/kiosk/printing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printing.url = (options?: RouteQueryOptions) => {
    return printing.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printing.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printing.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printing.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
const printingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printing.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

printing.form = printingForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
export const download = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/kiosk/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
download.url = (options?: RouteQueryOptions) => {
    return download.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
download.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
download.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
const downloadForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
downloadForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
downloadForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

download.form = downloadForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
export const thanks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: thanks.url(options),
    method: 'get',
})

thanks.definition = {
    methods: ["get","head"],
    url: '/kiosk/thanks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanks.url = (options?: RouteQueryOptions) => {
    return thanks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: thanks.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: thanks.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
const thanksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: thanks.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: thanks.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: thanks.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

thanks.form = thanksForm

const PageController = { welcome, welcomeDark, payment, qris, voucher, validatePay, frameSelect, capture, preview, filter, qty, confirm, extraPay, printing, download, thanks }

export default PageController
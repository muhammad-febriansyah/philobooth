import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/kiosk/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
startForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(options),
    method: 'post',
})

start.form = startForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectPaymentMethod
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
export const selectPaymentMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: selectPaymentMethod.url(options),
    method: 'post',
})

selectPaymentMethod.definition = {
    methods: ["post"],
    url: '/kiosk/payment/method',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectPaymentMethod
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
selectPaymentMethod.url = (options?: RouteQueryOptions) => {
    return selectPaymentMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectPaymentMethod
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
selectPaymentMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: selectPaymentMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectPaymentMethod
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
const selectPaymentMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: selectPaymentMethod.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectPaymentMethod
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
selectPaymentMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: selectPaymentMethod.url(options),
    method: 'post',
})

selectPaymentMethod.form = selectPaymentMethodForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mockPaySuccess
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
export const mockPaySuccess = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mockPaySuccess.url(options),
    method: 'post',
})

mockPaySuccess.definition = {
    methods: ["post"],
    url: '/kiosk/payment/mock-pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mockPaySuccess
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
mockPaySuccess.url = (options?: RouteQueryOptions) => {
    return mockPaySuccess.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mockPaySuccess
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
mockPaySuccess.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mockPaySuccess.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mockPaySuccess
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
const mockPaySuccessForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: mockPaySuccess.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mockPaySuccess
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
mockPaySuccessForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: mockPaySuccess.url(options),
    method: 'post',
})

mockPaySuccess.form = mockPaySuccessForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::payExtra
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
export const payExtra = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: payExtra.url(options),
    method: 'post',
})

payExtra.definition = {
    methods: ["post"],
    url: '/kiosk/extra-pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::payExtra
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
payExtra.url = (options?: RouteQueryOptions) => {
    return payExtra.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::payExtra
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
payExtra.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: payExtra.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::payExtra
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
const payExtraForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: payExtra.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::payExtra
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
payExtraForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: payExtra.url(options),
    method: 'post',
})

payExtra.form = payExtraForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
export const emailReceipt = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: emailReceipt.url(options),
    method: 'post',
})

emailReceipt.definition = {
    methods: ["post"],
    url: '/kiosk/email-receipt',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
emailReceipt.url = (options?: RouteQueryOptions) => {
    return emailReceipt.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
emailReceipt.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: emailReceipt.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
const emailReceiptForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: emailReceipt.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
emailReceiptForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: emailReceipt.url(options),
    method: 'post',
})

emailReceipt.form = emailReceiptForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::applyVoucher
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
export const applyVoucher = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: applyVoucher.url(options),
    method: 'post',
})

applyVoucher.definition = {
    methods: ["post"],
    url: '/kiosk/voucher/apply',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::applyVoucher
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
applyVoucher.url = (options?: RouteQueryOptions) => {
    return applyVoucher.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::applyVoucher
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
applyVoucher.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: applyVoucher.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::applyVoucher
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
const applyVoucherForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: applyVoucher.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::applyVoucher
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
applyVoucherForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: applyVoucher.url(options),
    method: 'post',
})

applyVoucher.form = applyVoucherForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFrame
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
export const selectFrame = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: selectFrame.url(options),
    method: 'post',
})

selectFrame.definition = {
    methods: ["post"],
    url: '/kiosk/frame',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFrame
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
selectFrame.url = (options?: RouteQueryOptions) => {
    return selectFrame.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFrame
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
selectFrame.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: selectFrame.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFrame
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
const selectFrameForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: selectFrame.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFrame
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
selectFrameForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: selectFrame.url(options),
    method: 'post',
})

selectFrame.form = selectFrameForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadPhotos
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
export const uploadPhotos = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadPhotos.url(options),
    method: 'post',
})

uploadPhotos.definition = {
    methods: ["post"],
    url: '/kiosk/photos',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadPhotos
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
uploadPhotos.url = (options?: RouteQueryOptions) => {
    return uploadPhotos.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadPhotos
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
uploadPhotos.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadPhotos.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadPhotos
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
const uploadPhotosForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadPhotos.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadPhotos
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
uploadPhotosForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadPhotos.url(options),
    method: 'post',
})

uploadPhotos.form = uploadPhotosForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadVideo
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
export const uploadVideo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadVideo.url(options),
    method: 'post',
})

uploadVideo.definition = {
    methods: ["post"],
    url: '/kiosk/video',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadVideo
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
uploadVideo.url = (options?: RouteQueryOptions) => {
    return uploadVideo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadVideo
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
uploadVideo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadVideo.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadVideo
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
const uploadVideoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadVideo.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::uploadVideo
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
uploadVideoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: uploadVideo.url(options),
    method: 'post',
})

uploadVideo.form = uploadVideoForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFilter
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
export const selectFilter = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: selectFilter.url(options),
    method: 'post',
})

selectFilter.definition = {
    methods: ["post"],
    url: '/kiosk/filter',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFilter
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
selectFilter.url = (options?: RouteQueryOptions) => {
    return selectFilter.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFilter
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
selectFilter.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: selectFilter.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFilter
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
const selectFilterForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: selectFilter.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::selectFilter
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
selectFilterForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: selectFilter.url(options),
    method: 'post',
})

selectFilter.form = selectFilterForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::setQuantity
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
export const setQuantity = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setQuantity.url(options),
    method: 'post',
})

setQuantity.definition = {
    methods: ["post"],
    url: '/kiosk/quantity',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::setQuantity
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
setQuantity.url = (options?: RouteQueryOptions) => {
    return setQuantity.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::setQuantity
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
setQuantity.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setQuantity.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::setQuantity
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
const setQuantityForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: setQuantity.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::setQuantity
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
setQuantityForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: setQuantity.url(options),
    method: 'post',
})

setQuantity.form = setQuantityForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
export const complete = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/kiosk/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
complete.url = (options?: RouteQueryOptions) => {
    return complete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
complete.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
const completeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
completeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(options),
    method: 'post',
})

complete.form = completeForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/kiosk/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(options),
    method: 'post',
})

cancel.form = cancelForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
export const status = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/kiosk/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
status.url = (options?: RouteQueryOptions) => {
    return status.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
status.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
status.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
const statusForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
statusForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
statusForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

status.form = statusForm

const SessionController = { start, selectPaymentMethod, mockPaySuccess, payExtra, emailReceipt, applyVoucher, selectFrame, uploadPhotos, uploadVideo, selectFilter, setQuantity, complete, cancel, status }

export default SessionController
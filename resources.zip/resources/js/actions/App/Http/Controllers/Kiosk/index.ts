import PageController from './PageController'
import SessionController from './SessionController'

const Kiosk = {
    PageController: Object.assign(PageController, PageController),
    SessionController: Object.assign(SessionController, SessionController),
}

export default Kiosk
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
const PakasirNotifyController = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PakasirNotifyController.url(options),
    method: 'post',
})

PakasirNotifyController.definition = {
    methods: ["post"],
    url: '/api/booth/pakasir/callback',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
PakasirNotifyController.url = (options?: RouteQueryOptions) => {
    return PakasirNotifyController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
PakasirNotifyController.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: PakasirNotifyController.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
const PakasirNotifyControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: PakasirNotifyController.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
PakasirNotifyControllerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: PakasirNotifyController.url(options),
    method: 'post',
})

PakasirNotifyController.form = PakasirNotifyControllerForm

export default PakasirNotifyController
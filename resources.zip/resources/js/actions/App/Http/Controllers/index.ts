import PakasirNotifyController from './PakasirNotifyController'
import DokuNotifyController from './DokuNotifyController'
import DashboardController from './DashboardController'
import Admin from './Admin'
import Kiosk from './Kiosk'
import DownloadController from './DownloadController'
import Settings from './Settings'

const Controllers = {
    PakasirNotifyController: Object.assign(PakasirNotifyController, PakasirNotifyController),
    DokuNotifyController: Object.assign(DokuNotifyController, DokuNotifyController),
    DashboardController: Object.assign(DashboardController, DashboardController),
    Admin: Object.assign(Admin, Admin),
    Kiosk: Object.assign(Kiosk, Kiosk),
    DownloadController: Object.assign(DownloadController, DownloadController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers
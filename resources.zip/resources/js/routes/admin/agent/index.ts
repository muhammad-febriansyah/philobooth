import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AgentController::download
* @see app/Http/Controllers/Admin/AgentController.php:43
* @route '/admin/agent-download'
*/
export const download = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/admin/agent-download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AgentController::download
* @see app/Http/Controllers/Admin/AgentController.php:43
* @route '/admin/agent-download'
*/
download.url = (options?: RouteQueryOptions) => {
    return download.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AgentController::download
* @see app/Http/Controllers/Admin/AgentController.php:43
* @route '/admin/agent-download'
*/
download.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentController::download
* @see app/Http/Controllers/Admin/AgentController.php:43
* @route '/admin/agent-download'
*/
download.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AgentController::download
* @see app/Http/Controllers/Admin/AgentController.php:43
* @route '/admin/agent-download'
*/
const downloadForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentController::download
* @see app/Http/Controllers/Admin/AgentController.php:43
* @route '/admin/agent-download'
*/
downloadForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AgentController::download
* @see app/Http/Controllers/Admin/AgentController.php:43
* @route '/admin/agent-download'
*/
downloadForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

download.form = downloadForm

const agent = {
    download: Object.assign(download, download),
}

export default agent
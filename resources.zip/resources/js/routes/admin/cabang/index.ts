import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CabangController::index
* @see app/Http/Controllers/Admin/CabangController.php:15
* @route '/admin/cabang'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/cabang',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CabangController::index
* @see app/Http/Controllers/Admin/CabangController.php:15
* @route '/admin/cabang'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CabangController::index
* @see app/Http/Controllers/Admin/CabangController.php:15
* @route '/admin/cabang'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::index
* @see app/Http/Controllers/Admin/CabangController.php:15
* @route '/admin/cabang'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::index
* @see app/Http/Controllers/Admin/CabangController.php:15
* @route '/admin/cabang'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::index
* @see app/Http/Controllers/Admin/CabangController.php:15
* @route '/admin/cabang'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::index
* @see app/Http/Controllers/Admin/CabangController.php:15
* @route '/admin/cabang'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\CabangController::store
* @see app/Http/Controllers/Admin/CabangController.php:66
* @route '/admin/cabang'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/cabang',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CabangController::store
* @see app/Http/Controllers/Admin/CabangController.php:66
* @route '/admin/cabang'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CabangController::store
* @see app/Http/Controllers/Admin/CabangController.php:66
* @route '/admin/cabang'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::store
* @see app/Http/Controllers/Admin/CabangController.php:66
* @route '/admin/cabang'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::store
* @see app/Http/Controllers/Admin/CabangController.php:66
* @route '/admin/cabang'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\CabangController::update
* @see app/Http/Controllers/Admin/CabangController.php:73
* @route '/admin/cabang/{cabang}'
*/
export const update = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/cabang/{cabang}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\CabangController::update
* @see app/Http/Controllers/Admin/CabangController.php:73
* @route '/admin/cabang/{cabang}'
*/
update.url = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cabang: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cabang: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cabang: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cabang: typeof args.cabang === 'object'
        ? args.cabang.id
        : args.cabang,
    }

    return update.definition.url
            .replace('{cabang}', parsedArgs.cabang.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CabangController::update
* @see app/Http/Controllers/Admin/CabangController.php:73
* @route '/admin/cabang/{cabang}'
*/
update.put = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::update
* @see app/Http/Controllers/Admin/CabangController.php:73
* @route '/admin/cabang/{cabang}'
*/
const updateForm = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::update
* @see app/Http/Controllers/Admin/CabangController.php:73
* @route '/admin/cabang/{cabang}'
*/
updateForm.put = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\CabangController::destroy
* @see app/Http/Controllers/Admin/CabangController.php:80
* @route '/admin/cabang/{cabang}'
*/
export const destroy = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/cabang/{cabang}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\CabangController::destroy
* @see app/Http/Controllers/Admin/CabangController.php:80
* @route '/admin/cabang/{cabang}'
*/
destroy.url = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cabang: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { cabang: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            cabang: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        cabang: typeof args.cabang === 'object'
        ? args.cabang.id
        : args.cabang,
    }

    return destroy.definition.url
            .replace('{cabang}', parsedArgs.cabang.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CabangController::destroy
* @see app/Http/Controllers/Admin/CabangController.php:80
* @route '/admin/cabang/{cabang}'
*/
destroy.delete = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::destroy
* @see app/Http/Controllers/Admin/CabangController.php:80
* @route '/admin/cabang/{cabang}'
*/
const destroyForm = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CabangController::destroy
* @see app/Http/Controllers/Admin/CabangController.php:80
* @route '/admin/cabang/{cabang}'
*/
destroyForm.delete = (args: { cabang: number | { id: number } } | [cabang: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const cabang = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default cabang
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\FrameController::index
* @see app/Http/Controllers/Admin/FrameController.php:27
* @route '/admin/frames'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/frames',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FrameController::index
* @see app/Http/Controllers/Admin/FrameController.php:27
* @route '/admin/frames'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FrameController::index
* @see app/Http/Controllers/Admin/FrameController.php:27
* @route '/admin/frames'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::index
* @see app/Http/Controllers/Admin/FrameController.php:27
* @route '/admin/frames'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::index
* @see app/Http/Controllers/Admin/FrameController.php:27
* @route '/admin/frames'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::index
* @see app/Http/Controllers/Admin/FrameController.php:27
* @route '/admin/frames'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::index
* @see app/Http/Controllers/Admin/FrameController.php:27
* @route '/admin/frames'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\FrameController::create
* @see app/Http/Controllers/Admin/FrameController.php:91
* @route '/admin/frames/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/frames/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FrameController::create
* @see app/Http/Controllers/Admin/FrameController.php:91
* @route '/admin/frames/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FrameController::create
* @see app/Http/Controllers/Admin/FrameController.php:91
* @route '/admin/frames/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::create
* @see app/Http/Controllers/Admin/FrameController.php:91
* @route '/admin/frames/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::create
* @see app/Http/Controllers/Admin/FrameController.php:91
* @route '/admin/frames/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::create
* @see app/Http/Controllers/Admin/FrameController.php:91
* @route '/admin/frames/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::create
* @see app/Http/Controllers/Admin/FrameController.php:91
* @route '/admin/frames/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\FrameController::store
* @see app/Http/Controllers/Admin/FrameController.php:149
* @route '/admin/frames'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/frames',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\FrameController::store
* @see app/Http/Controllers/Admin/FrameController.php:149
* @route '/admin/frames'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FrameController::store
* @see app/Http/Controllers/Admin/FrameController.php:149
* @route '/admin/frames'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::store
* @see app/Http/Controllers/Admin/FrameController.php:149
* @route '/admin/frames'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::store
* @see app/Http/Controllers/Admin/FrameController.php:149
* @route '/admin/frames'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\FrameController::edit
* @see app/Http/Controllers/Admin/FrameController.php:96
* @route '/admin/frames/{frame}/edit'
*/
export const edit = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/frames/{frame}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FrameController::edit
* @see app/Http/Controllers/Admin/FrameController.php:96
* @route '/admin/frames/{frame}/edit'
*/
edit.url = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { frame: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { frame: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            frame: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        frame: typeof args.frame === 'object'
        ? args.frame.id
        : args.frame,
    }

    return edit.definition.url
            .replace('{frame}', parsedArgs.frame.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FrameController::edit
* @see app/Http/Controllers/Admin/FrameController.php:96
* @route '/admin/frames/{frame}/edit'
*/
edit.get = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::edit
* @see app/Http/Controllers/Admin/FrameController.php:96
* @route '/admin/frames/{frame}/edit'
*/
edit.head = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::edit
* @see app/Http/Controllers/Admin/FrameController.php:96
* @route '/admin/frames/{frame}/edit'
*/
const editForm = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::edit
* @see app/Http/Controllers/Admin/FrameController.php:96
* @route '/admin/frames/{frame}/edit'
*/
editForm.get = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::edit
* @see app/Http/Controllers/Admin/FrameController.php:96
* @route '/admin/frames/{frame}/edit'
*/
editForm.head = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\FrameController::update
* @see app/Http/Controllers/Admin/FrameController.php:214
* @route '/admin/frames/{frame}'
*/
export const update = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/admin/frames/{frame}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\FrameController::update
* @see app/Http/Controllers/Admin/FrameController.php:214
* @route '/admin/frames/{frame}'
*/
update.url = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { frame: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { frame: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            frame: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        frame: typeof args.frame === 'object'
        ? args.frame.id
        : args.frame,
    }

    return update.definition.url
            .replace('{frame}', parsedArgs.frame.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FrameController::update
* @see app/Http/Controllers/Admin/FrameController.php:214
* @route '/admin/frames/{frame}'
*/
update.post = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::update
* @see app/Http/Controllers/Admin/FrameController.php:214
* @route '/admin/frames/{frame}'
*/
const updateForm = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::update
* @see app/Http/Controllers/Admin/FrameController.php:214
* @route '/admin/frames/{frame}'
*/
updateForm.post = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, options),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\FrameController::destroy
* @see app/Http/Controllers/Admin/FrameController.php:289
* @route '/admin/frames/{frame}'
*/
export const destroy = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/frames/{frame}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\FrameController::destroy
* @see app/Http/Controllers/Admin/FrameController.php:289
* @route '/admin/frames/{frame}'
*/
destroy.url = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { frame: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { frame: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            frame: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        frame: typeof args.frame === 'object'
        ? args.frame.id
        : args.frame,
    }

    return destroy.definition.url
            .replace('{frame}', parsedArgs.frame.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FrameController::destroy
* @see app/Http/Controllers/Admin/FrameController.php:289
* @route '/admin/frames/{frame}'
*/
destroy.delete = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::destroy
* @see app/Http/Controllers/Admin/FrameController.php:289
* @route '/admin/frames/{frame}'
*/
const destroyForm = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::destroy
* @see app/Http/Controllers/Admin/FrameController.php:289
* @route '/admin/frames/{frame}'
*/
destroyForm.delete = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Admin\FrameController::preview
* @see app/Http/Controllers/Admin/FrameController.php:300
* @route '/admin/frames/{frame}/preview'
*/
export const preview = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/admin/frames/{frame}/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\FrameController::preview
* @see app/Http/Controllers/Admin/FrameController.php:300
* @route '/admin/frames/{frame}/preview'
*/
preview.url = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { frame: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { frame: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            frame: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        frame: typeof args.frame === 'object'
        ? args.frame.id
        : args.frame,
    }

    return preview.definition.url
            .replace('{frame}', parsedArgs.frame.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\FrameController::preview
* @see app/Http/Controllers/Admin/FrameController.php:300
* @route '/admin/frames/{frame}/preview'
*/
preview.get = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::preview
* @see app/Http/Controllers/Admin/FrameController.php:300
* @route '/admin/frames/{frame}/preview'
*/
preview.head = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::preview
* @see app/Http/Controllers/Admin/FrameController.php:300
* @route '/admin/frames/{frame}/preview'
*/
const previewForm = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::preview
* @see app/Http/Controllers/Admin/FrameController.php:300
* @route '/admin/frames/{frame}/preview'
*/
previewForm.get = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\FrameController::preview
* @see app/Http/Controllers/Admin/FrameController.php:300
* @route '/admin/frames/{frame}/preview'
*/
previewForm.head = (args: { frame: number | { id: number } } | [frame: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

preview.form = previewForm

const frames = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
    preview: Object.assign(preview, preview),
}

export default frames
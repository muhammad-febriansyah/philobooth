import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import cabang from './cabang'
import settings from './settings'
import users from './users'
import agent from './agent'
import voucher from './voucher'
import printer from './printer'
import frames from './frames'
import transaksi from './transaksi'
/**
* @see \App\Http\Controllers\Admin\GlobalSearchController::__invoke
* @see app/Http/Controllers/Admin/GlobalSearchController.php:21
* @route '/admin/search'
*/
export const search = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

search.definition = {
    methods: ["get","head"],
    url: '/admin/search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\GlobalSearchController::__invoke
* @see app/Http/Controllers/Admin/GlobalSearchController.php:21
* @route '/admin/search'
*/
search.url = (options?: RouteQueryOptions) => {
    return search.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\GlobalSearchController::__invoke
* @see app/Http/Controllers/Admin/GlobalSearchController.php:21
* @route '/admin/search'
*/
search.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\GlobalSearchController::__invoke
* @see app/Http/Controllers/Admin/GlobalSearchController.php:21
* @route '/admin/search'
*/
search.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: search.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\GlobalSearchController::__invoke
* @see app/Http/Controllers/Admin/GlobalSearchController.php:21
* @route '/admin/search'
*/
const searchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\GlobalSearchController::__invoke
* @see app/Http/Controllers/Admin/GlobalSearchController.php:21
* @route '/admin/search'
*/
searchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\GlobalSearchController::__invoke
* @see app/Http/Controllers/Admin/GlobalSearchController.php:21
* @route '/admin/search'
*/
searchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: search.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

search.form = searchForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/admin/frame-builder'
*/
export const frameBuilder = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: frameBuilder.url(options),
    method: 'get',
})

frameBuilder.definition = {
    methods: ["get","head"],
    url: '/admin/frame-builder',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/admin/frame-builder'
*/
frameBuilder.url = (options?: RouteQueryOptions) => {
    return frameBuilder.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/admin/frame-builder'
*/
frameBuilder.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: frameBuilder.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/admin/frame-builder'
*/
frameBuilder.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: frameBuilder.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/admin/frame-builder'
*/
const frameBuilderForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameBuilder.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/admin/frame-builder'
*/
frameBuilderForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameBuilder.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/admin/frame-builder'
*/
frameBuilderForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameBuilder.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

frameBuilder.form = frameBuilderForm

const admin = {
    cabang: Object.assign(cabang, cabang),
    settings: Object.assign(settings, settings),
    users: Object.assign(users, users),
    search: Object.assign(search, search),
    agent: Object.assign(agent, agent),
    voucher: Object.assign(voucher, voucher),
    printer: Object.assign(printer, printer),
    frames: Object.assign(frames, frames),
    frameBuilder: Object.assign(frameBuilder, frameBuilder),
    transaksi: Object.assign(transaksi, transaksi),
}

export default admin
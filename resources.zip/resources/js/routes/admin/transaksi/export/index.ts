import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\TransaksiController::pdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
export const pdf = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/admin/transaksi/export/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TransaksiController::pdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
pdf.url = (options?: RouteQueryOptions) => {
    return pdf.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TransaksiController::pdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
pdf.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::pdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
pdf.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::pdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
const pdfForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::pdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
pdfForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::pdf
* @see app/Http/Controllers/Admin/TransaksiController.php:72
* @route '/admin/transaksi/export/pdf'
*/
pdfForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pdf.form = pdfForm

/**
* @see \App\Http\Controllers\Admin\TransaksiController::csv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
export const csv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: csv.url(options),
    method: 'get',
})

csv.definition = {
    methods: ["get","head"],
    url: '/admin/transaksi/export/csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TransaksiController::csv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
csv.url = (options?: RouteQueryOptions) => {
    return csv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TransaksiController::csv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
csv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: csv.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::csv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
csv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: csv.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::csv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
const csvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: csv.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::csv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
csvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: csv.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::csv
* @see app/Http/Controllers/Admin/TransaksiController.php:95
* @route '/admin/transaksi/export/csv'
*/
csvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: csv.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

csv.form = csvForm

const exportMethod = {
    pdf: Object.assign(pdf, pdf),
    csv: Object.assign(csv, csv),
}

export default exportMethod
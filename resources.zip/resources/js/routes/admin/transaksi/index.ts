import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import exportMethod from './export'
/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/transaksi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\TransaksiController::index
* @see app/Http/Controllers/Admin/TransaksiController.php:20
* @route '/admin/transaksi'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const transaksi = {
    index: Object.assign(index, index),
    export: Object.assign(exportMethod, exportMethod),
}

export default transaksi
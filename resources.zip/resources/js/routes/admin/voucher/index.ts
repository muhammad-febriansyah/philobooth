import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\VoucherController::index
* @see app/Http/Controllers/Admin/VoucherController.php:24
* @route '/admin/voucher'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/voucher',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VoucherController::index
* @see app/Http/Controllers/Admin/VoucherController.php:24
* @route '/admin/voucher'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VoucherController::index
* @see app/Http/Controllers/Admin/VoucherController.php:24
* @route '/admin/voucher'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::index
* @see app/Http/Controllers/Admin/VoucherController.php:24
* @route '/admin/voucher'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::index
* @see app/Http/Controllers/Admin/VoucherController.php:24
* @route '/admin/voucher'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::index
* @see app/Http/Controllers/Admin/VoucherController.php:24
* @route '/admin/voucher'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::index
* @see app/Http/Controllers/Admin/VoucherController.php:24
* @route '/admin/voucher'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\VoucherController::store
* @see app/Http/Controllers/Admin/VoucherController.php:83
* @route '/admin/voucher'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/voucher',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\VoucherController::store
* @see app/Http/Controllers/Admin/VoucherController.php:83
* @route '/admin/voucher'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VoucherController::store
* @see app/Http/Controllers/Admin/VoucherController.php:83
* @route '/admin/voucher'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::store
* @see app/Http/Controllers/Admin/VoucherController.php:83
* @route '/admin/voucher'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::store
* @see app/Http/Controllers/Admin/VoucherController.php:83
* @route '/admin/voucher'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\VoucherController::pdf
* @see app/Http/Controllers/Admin/VoucherController.php:104
* @route '/admin/voucher/{voucher}/pdf'
*/
export const pdf = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

pdf.definition = {
    methods: ["get","head"],
    url: '/admin/voucher/{voucher}/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VoucherController::pdf
* @see app/Http/Controllers/Admin/VoucherController.php:104
* @route '/admin/voucher/{voucher}/pdf'
*/
pdf.url = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { voucher: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { voucher: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            voucher: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        voucher: typeof args.voucher === 'object'
        ? args.voucher.id
        : args.voucher,
    }

    return pdf.definition.url
            .replace('{voucher}', parsedArgs.voucher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VoucherController::pdf
* @see app/Http/Controllers/Admin/VoucherController.php:104
* @route '/admin/voucher/{voucher}/pdf'
*/
pdf.get = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pdf.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::pdf
* @see app/Http/Controllers/Admin/VoucherController.php:104
* @route '/admin/voucher/{voucher}/pdf'
*/
pdf.head = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pdf.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::pdf
* @see app/Http/Controllers/Admin/VoucherController.php:104
* @route '/admin/voucher/{voucher}/pdf'
*/
const pdfForm = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::pdf
* @see app/Http/Controllers/Admin/VoucherController.php:104
* @route '/admin/voucher/{voucher}/pdf'
*/
pdfForm.get = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::pdf
* @see app/Http/Controllers/Admin/VoucherController.php:104
* @route '/admin/voucher/{voucher}/pdf'
*/
pdfForm.head = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pdf.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pdf.form = pdfForm

/**
* @see \App\Http\Controllers\Admin\VoucherController::update
* @see app/Http/Controllers/Admin/VoucherController.php:90
* @route '/admin/voucher/{voucher}'
*/
export const update = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/voucher/{voucher}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\VoucherController::update
* @see app/Http/Controllers/Admin/VoucherController.php:90
* @route '/admin/voucher/{voucher}'
*/
update.url = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { voucher: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { voucher: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            voucher: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        voucher: typeof args.voucher === 'object'
        ? args.voucher.id
        : args.voucher,
    }

    return update.definition.url
            .replace('{voucher}', parsedArgs.voucher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VoucherController::update
* @see app/Http/Controllers/Admin/VoucherController.php:90
* @route '/admin/voucher/{voucher}'
*/
update.put = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::update
* @see app/Http/Controllers/Admin/VoucherController.php:90
* @route '/admin/voucher/{voucher}'
*/
const updateForm = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::update
* @see app/Http/Controllers/Admin/VoucherController.php:90
* @route '/admin/voucher/{voucher}'
*/
updateForm.put = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\VoucherController::destroy
* @see app/Http/Controllers/Admin/VoucherController.php:97
* @route '/admin/voucher/{voucher}'
*/
export const destroy = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/voucher/{voucher}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\VoucherController::destroy
* @see app/Http/Controllers/Admin/VoucherController.php:97
* @route '/admin/voucher/{voucher}'
*/
destroy.url = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { voucher: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { voucher: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            voucher: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        voucher: typeof args.voucher === 'object'
        ? args.voucher.id
        : args.voucher,
    }

    return destroy.definition.url
            .replace('{voucher}', parsedArgs.voucher.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VoucherController::destroy
* @see app/Http/Controllers/Admin/VoucherController.php:97
* @route '/admin/voucher/{voucher}'
*/
destroy.delete = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::destroy
* @see app/Http/Controllers/Admin/VoucherController.php:97
* @route '/admin/voucher/{voucher}'
*/
const destroyForm = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\VoucherController::destroy
* @see app/Http/Controllers/Admin/VoucherController.php:97
* @route '/admin/voucher/{voucher}'
*/
destroyForm.delete = (args: { voucher: number | { id: number } } | [voucher: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const voucher = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    pdf: Object.assign(pdf, pdf),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default voucher
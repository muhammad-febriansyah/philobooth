import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
export const notify = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: notify.url(options),
    method: 'post',
})

notify.definition = {
    methods: ["post"],
    url: '/api/booth/payment/callback',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
notify.url = (options?: RouteQueryOptions) => {
    return notify.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
notify.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: notify.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
const notifyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: notify.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\DokuNotifyController::__invoke
* @see app/Http/Controllers/DokuNotifyController.php:23
* @route '/api/booth/payment/callback'
*/
notifyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: notify.url(options),
    method: 'post',
})

notify.form = notifyForm

const doku = {
    notify: Object.assign(notify, notify),
}

export default doku
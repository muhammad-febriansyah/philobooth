import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\DownloadController::show
* @see app/Http/Controllers/DownloadController.php:22
* @route '/d/{token}'
*/
export const show = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/d/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DownloadController::show
* @see app/Http/Controllers/DownloadController.php:22
* @route '/d/{token}'
*/
show.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return show.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DownloadController::show
* @see app/Http/Controllers/DownloadController.php:22
* @route '/d/{token}'
*/
show.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::show
* @see app/Http/Controllers/DownloadController.php:22
* @route '/d/{token}'
*/
show.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DownloadController::show
* @see app/Http/Controllers/DownloadController.php:22
* @route '/d/{token}'
*/
const showForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::show
* @see app/Http/Controllers/DownloadController.php:22
* @route '/d/{token}'
*/
showForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::show
* @see app/Http/Controllers/DownloadController.php:22
* @route '/d/{token}'
*/
showForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\DownloadController::file
* @see app/Http/Controllers/DownloadController.php:54
* @route '/d/{token}/file'
*/
export const file = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: file.url(args, options),
    method: 'get',
})

file.definition = {
    methods: ["get","head"],
    url: '/d/{token}/file',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DownloadController::file
* @see app/Http/Controllers/DownloadController.php:54
* @route '/d/{token}/file'
*/
file.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return file.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DownloadController::file
* @see app/Http/Controllers/DownloadController.php:54
* @route '/d/{token}/file'
*/
file.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: file.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::file
* @see app/Http/Controllers/DownloadController.php:54
* @route '/d/{token}/file'
*/
file.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: file.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DownloadController::file
* @see app/Http/Controllers/DownloadController.php:54
* @route '/d/{token}/file'
*/
const fileForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: file.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::file
* @see app/Http/Controllers/DownloadController.php:54
* @route '/d/{token}/file'
*/
fileForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: file.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::file
* @see app/Http/Controllers/DownloadController.php:54
* @route '/d/{token}/file'
*/
fileForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: file.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

file.form = fileForm

/**
* @see \App\Http\Controllers\DownloadController::zip
* @see app/Http/Controllers/DownloadController.php:77
* @route '/d/{token}/zip'
*/
export const zip = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: zip.url(args, options),
    method: 'get',
})

zip.definition = {
    methods: ["get","head"],
    url: '/d/{token}/zip',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DownloadController::zip
* @see app/Http/Controllers/DownloadController.php:77
* @route '/d/{token}/zip'
*/
zip.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    if (Array.isArray(args)) {
        args = {
            token: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        token: args.token,
    }

    return zip.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DownloadController::zip
* @see app/Http/Controllers/DownloadController.php:77
* @route '/d/{token}/zip'
*/
zip.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: zip.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::zip
* @see app/Http/Controllers/DownloadController.php:77
* @route '/d/{token}/zip'
*/
zip.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: zip.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DownloadController::zip
* @see app/Http/Controllers/DownloadController.php:77
* @route '/d/{token}/zip'
*/
const zipForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: zip.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::zip
* @see app/Http/Controllers/DownloadController.php:77
* @route '/d/{token}/zip'
*/
zipForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: zip.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DownloadController::zip
* @see app/Http/Controllers/DownloadController.php:77
* @route '/d/{token}/zip'
*/
zipForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: zip.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

zip.form = zipForm

const download = {
    show: Object.assign(show, show),
    file: Object.assign(file, file),
    zip: Object.assign(zip, zip),
}

export default download
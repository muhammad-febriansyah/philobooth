import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::submit
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
export const submit = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/kiosk/extra-pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::submit
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
submit.url = (options?: RouteQueryOptions) => {
    return submit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::submit
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
submit.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::submit
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
const submitForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::submit
* @see app/Http/Controllers/Kiosk/SessionController.php:522
* @route '/kiosk/extra-pay'
*/
submitForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(options),
    method: 'post',
})

submit.form = submitForm

const extraPay = {
    submit: Object.assign(submit, submit),
}

export default extraPay
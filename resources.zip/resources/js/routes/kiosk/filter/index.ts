import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
export const select = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: select.url(options),
    method: 'post',
})

select.definition = {
    methods: ["post"],
    url: '/kiosk/filter',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
select.url = (options?: RouteQueryOptions) => {
    return select.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
select.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: select.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
const selectForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: select.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:439
* @route '/kiosk/filter'
*/
selectForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: select.url(options),
    method: 'post',
})

select.form = selectForm

const filter = {
    select: Object.assign(select, select),
}

export default filter
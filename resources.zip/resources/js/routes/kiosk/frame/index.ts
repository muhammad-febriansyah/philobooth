import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
export const select = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: select.url(options),
    method: 'post',
})

select.definition = {
    methods: ["post"],
    url: '/kiosk/frame',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
select.url = (options?: RouteQueryOptions) => {
    return select.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
select.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: select.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
const selectForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: select.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::select
* @see app/Http/Controllers/Kiosk/SessionController.php:300
* @route '/kiosk/frame'
*/
selectForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: select.url(options),
    method: 'post',
})

select.form = selectForm

const frame = {
    select: Object.assign(select, select),
}

export default frame
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import payment44796b from './payment'
import voucherF8aca0 from './voucher'
import filterDa23af from './filter'
import extraPayE95fab from './extra-pay'
import frame from './frame'
import photos from './photos'
import video from './video'
import quantity from './quantity'
/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
export const welcome = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: welcome.url(options),
    method: 'get',
})

welcome.definition = {
    methods: ["get","head"],
    url: '/kiosk/welcome',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcome.url = (options?: RouteQueryOptions) => {
    return welcome.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcome.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: welcome.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcome.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: welcome.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
const welcomeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcome.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcomeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcome.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcome
* @see app/Http/Controllers/Kiosk/PageController.php:31
* @route '/kiosk/welcome'
*/
welcomeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcome.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

welcome.form = welcomeForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
export const welcomeDark = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: welcomeDark.url(options),
    method: 'get',
})

welcomeDark.definition = {
    methods: ["get","head"],
    url: '/kiosk/welcome-dark',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDark.url = (options?: RouteQueryOptions) => {
    return welcomeDark.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDark.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: welcomeDark.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDark.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: welcomeDark.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
const welcomeDarkForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcomeDark.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDarkForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcomeDark.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::welcomeDark
* @see app/Http/Controllers/Kiosk/PageController.php:42
* @route '/kiosk/welcome-dark'
*/
welcomeDarkForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: welcomeDark.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

welcomeDark.form = welcomeDarkForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
export const payment = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payment.url(options),
    method: 'get',
})

payment.definition = {
    methods: ["get","head"],
    url: '/kiosk/payment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
payment.url = (options?: RouteQueryOptions) => {
    return payment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
payment.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: payment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
payment.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: payment.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
const paymentForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
paymentForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::payment
* @see app/Http/Controllers/Kiosk/PageController.php:53
* @route '/kiosk/payment'
*/
paymentForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: payment.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

payment.form = paymentForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
export const qris = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qris.url(options),
    method: 'get',
})

qris.definition = {
    methods: ["get","head"],
    url: '/kiosk/qris',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qris.url = (options?: RouteQueryOptions) => {
    return qris.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qris.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qris.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qris.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qris.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
const qrisForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qris.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qrisForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qris.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qris
* @see app/Http/Controllers/Kiosk/PageController.php:62
* @route '/kiosk/qris'
*/
qrisForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qris.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

qris.form = qrisForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
export const voucher = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: voucher.url(options),
    method: 'get',
})

voucher.definition = {
    methods: ["get","head"],
    url: '/kiosk/voucher',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucher.url = (options?: RouteQueryOptions) => {
    return voucher.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucher.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: voucher.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucher.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: voucher.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
const voucherForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucherForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::voucher
* @see app/Http/Controllers/Kiosk/PageController.php:97
* @route '/kiosk/voucher'
*/
voucherForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: voucher.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

voucher.form = voucherForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::validate
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
export const validate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: validate.url(options),
    method: 'get',
})

validate.definition = {
    methods: ["get","head"],
    url: '/kiosk/validate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::validate
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validate.url = (options?: RouteQueryOptions) => {
    return validate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::validate
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: validate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::validate
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: validate.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::validate
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
const validateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: validate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::validate
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: validate.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::validate
* @see app/Http/Controllers/Kiosk/PageController.php:106
* @route '/kiosk/validate'
*/
validateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: validate.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

validate.form = validateForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
export const frameSelect = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: frameSelect.url(options),
    method: 'get',
})

frameSelect.definition = {
    methods: ["get","head"],
    url: '/kiosk/frame-select',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelect.url = (options?: RouteQueryOptions) => {
    return frameSelect.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelect.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: frameSelect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelect.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: frameSelect.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
const frameSelectForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameSelect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelectForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameSelect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::frameSelect
* @see app/Http/Controllers/Kiosk/PageController.php:115
* @route '/kiosk/frame-select'
*/
frameSelectForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: frameSelect.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

frameSelect.form = frameSelectForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
export const capture = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: capture.url(options),
    method: 'get',
})

capture.definition = {
    methods: ["get","head"],
    url: '/kiosk/capture',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
capture.url = (options?: RouteQueryOptions) => {
    return capture.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
capture.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: capture.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
capture.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: capture.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
const captureForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: capture.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
captureForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: capture.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::capture
* @see app/Http/Controllers/Kiosk/PageController.php:143
* @route '/kiosk/capture'
*/
captureForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: capture.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

capture.form = captureForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
export const preview = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/kiosk/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
preview.url = (options?: RouteQueryOptions) => {
    return preview.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
preview.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
preview.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
const previewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
previewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::preview
* @see app/Http/Controllers/Kiosk/PageController.php:187
* @route '/kiosk/preview'
*/
previewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

preview.form = previewForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
export const filter = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filter.url(options),
    method: 'get',
})

filter.definition = {
    methods: ["get","head"],
    url: '/kiosk/filter',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filter.url = (options?: RouteQueryOptions) => {
    return filter.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filter.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filter.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: filter.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
const filterForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filterForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::filter
* @see app/Http/Controllers/Kiosk/PageController.php:249
* @route '/kiosk/filter'
*/
filterForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: filter.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

filter.form = filterForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
export const qty = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qty.url(options),
    method: 'get',
})

qty.definition = {
    methods: ["get","head"],
    url: '/kiosk/qty',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qty.url = (options?: RouteQueryOptions) => {
    return qty.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qty.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: qty.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qty.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: qty.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
const qtyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qty.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qtyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qty.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::qty
* @see app/Http/Controllers/Kiosk/PageController.php:295
* @route '/kiosk/qty'
*/
qtyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: qty.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

qty.form = qtyForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
export const confirm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirm.url(options),
    method: 'get',
})

confirm.definition = {
    methods: ["get","head"],
    url: '/kiosk/confirm',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirm.url = (options?: RouteQueryOptions) => {
    return confirm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: confirm.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
const confirmForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirmForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::confirm
* @see app/Http/Controllers/Kiosk/PageController.php:381
* @route '/kiosk/confirm'
*/
confirmForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: confirm.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

confirm.form = confirmForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
export const extraPay = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: extraPay.url(options),
    method: 'get',
})

extraPay.definition = {
    methods: ["get","head"],
    url: '/kiosk/extra-pay',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPay.url = (options?: RouteQueryOptions) => {
    return extraPay.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPay.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: extraPay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPay.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: extraPay.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
const extraPayForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: extraPay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPayForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: extraPay.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::extraPay
* @see app/Http/Controllers/Kiosk/PageController.php:369
* @route '/kiosk/extra-pay'
*/
extraPayForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: extraPay.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

extraPay.form = extraPayForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
export const printing = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printing.url(options),
    method: 'get',
})

printing.definition = {
    methods: ["get","head"],
    url: '/kiosk/printing',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printing.url = (options?: RouteQueryOptions) => {
    return printing.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printing.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: printing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printing.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: printing.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
const printingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printing.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::printing
* @see app/Http/Controllers/Kiosk/PageController.php:404
* @route '/kiosk/printing'
*/
printingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: printing.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

printing.form = printingForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
export const download = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/kiosk/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
download.url = (options?: RouteQueryOptions) => {
    return download.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
download.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
download.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
const downloadForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
downloadForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::download
* @see app/Http/Controllers/Kiosk/PageController.php:413
* @route '/kiosk/download'
*/
downloadForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

download.form = downloadForm

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
export const thanks = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: thanks.url(options),
    method: 'get',
})

thanks.definition = {
    methods: ["get","head"],
    url: '/kiosk/thanks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanks.url = (options?: RouteQueryOptions) => {
    return thanks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanks.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: thanks.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanks.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: thanks.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
const thanksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: thanks.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: thanks.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\PageController::thanks
* @see app/Http/Controllers/Kiosk/PageController.php:445
* @route '/kiosk/thanks'
*/
thanksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: thanks.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

thanks.form = thanksForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/kiosk/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
const startForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::start
* @see app/Http/Controllers/Kiosk/SessionController.php:46
* @route '/kiosk/start'
*/
startForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(options),
    method: 'post',
})

start.form = startForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
export const emailReceipt = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: emailReceipt.url(options),
    method: 'post',
})

emailReceipt.definition = {
    methods: ["post"],
    url: '/kiosk/email-receipt',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
emailReceipt.url = (options?: RouteQueryOptions) => {
    return emailReceipt.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
emailReceipt.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: emailReceipt.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
const emailReceiptForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: emailReceipt.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::emailReceipt
* @see app/Http/Controllers/Kiosk/SessionController.php:667
* @route '/kiosk/email-receipt'
*/
emailReceiptForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: emailReceipt.url(options),
    method: 'post',
})

emailReceipt.form = emailReceiptForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
export const complete = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/kiosk/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
complete.url = (options?: RouteQueryOptions) => {
    return complete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
complete.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
const completeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::complete
* @see app/Http/Controllers/Kiosk/SessionController.php:557
* @route '/kiosk/complete'
*/
completeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(options),
    method: 'post',
})

complete.form = completeForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/kiosk/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
cancel.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::cancel
* @see app/Http/Controllers/Kiosk/SessionController.php:698
* @route '/kiosk/cancel'
*/
cancelForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: cancel.url(options),
    method: 'post',
})

cancel.form = cancelForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
export const status = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/kiosk/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
status.url = (options?: RouteQueryOptions) => {
    return status.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
status.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
status.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
const statusForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
statusForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::status
* @see app/Http/Controllers/Kiosk/SessionController.php:714
* @route '/kiosk/status'
*/
statusForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: status.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

status.form = statusForm

const kiosk = {
    welcome: Object.assign(welcome, welcome),
    welcomeDark: Object.assign(welcomeDark, welcomeDark),
    payment: Object.assign(payment, payment44796b),
    qris: Object.assign(qris, qris),
    voucher: Object.assign(voucher, voucherF8aca0),
    validate: Object.assign(validate, validate),
    frameSelect: Object.assign(frameSelect, frameSelect),
    capture: Object.assign(capture, capture),
    preview: Object.assign(preview, preview),
    filter: Object.assign(filter, filterDa23af),
    qty: Object.assign(qty, qty),
    confirm: Object.assign(confirm, confirm),
    extraPay: Object.assign(extraPay, extraPayE95fab),
    printing: Object.assign(printing, printing),
    download: Object.assign(download, download),
    thanks: Object.assign(thanks, thanks),
    start: Object.assign(start, start),
    emailReceipt: Object.assign(emailReceipt, emailReceipt),
    frame: Object.assign(frame, frame),
    photos: Object.assign(photos, photos),
    video: Object.assign(video, video),
    quantity: Object.assign(quantity, quantity),
    complete: Object.assign(complete, complete),
    cancel: Object.assign(cancel, cancel),
    status: Object.assign(status, status),
}

export default kiosk
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::method
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
export const method = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: method.url(options),
    method: 'post',
})

method.definition = {
    methods: ["post"],
    url: '/kiosk/payment/method',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::method
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
method.url = (options?: RouteQueryOptions) => {
    return method.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::method
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
method.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: method.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::method
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
const methodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: method.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::method
* @see app/Http/Controllers/Kiosk/SessionController.php:84
* @route '/kiosk/payment/method'
*/
methodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: method.url(options),
    method: 'post',
})

method.form = methodForm

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mock
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
export const mock = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mock.url(options),
    method: 'post',
})

mock.definition = {
    methods: ["post"],
    url: '/kiosk/payment/mock-pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mock
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
mock.url = (options?: RouteQueryOptions) => {
    return mock.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mock
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
mock.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mock.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mock
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
const mockForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: mock.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::mock
* @see app/Http/Controllers/Kiosk/SessionController.php:195
* @route '/kiosk/payment/mock-pay'
*/
mockForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: mock.url(options),
    method: 'post',
})

mock.form = mockForm

const payment = {
    method: Object.assign(method, method),
    mock: Object.assign(mock, mock),
}

export default payment
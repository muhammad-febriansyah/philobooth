import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
export const upload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

upload.definition = {
    methods: ["post"],
    url: '/kiosk/photos',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
upload.url = (options?: RouteQueryOptions) => {
    return upload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
upload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
const uploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upload.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:381
* @route '/kiosk/photos'
*/
uploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upload.url(options),
    method: 'post',
})

upload.form = uploadForm

const photos = {
    upload: Object.assign(upload, upload),
}

export default photos
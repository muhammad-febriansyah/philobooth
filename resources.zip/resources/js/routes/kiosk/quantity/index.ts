import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::set
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
export const set = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: set.url(options),
    method: 'post',
})

set.definition = {
    methods: ["post"],
    url: '/kiosk/quantity',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::set
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
set.url = (options?: RouteQueryOptions) => {
    return set.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::set
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
set.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: set.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::set
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
const setForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: set.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::set
* @see app/Http/Controllers/Kiosk/SessionController.php:486
* @route '/kiosk/quantity'
*/
setForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: set.url(options),
    method: 'post',
})

set.form = setForm

const quantity = {
    set: Object.assign(set, set),
}

export default quantity
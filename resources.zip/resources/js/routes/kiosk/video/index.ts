import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
export const upload = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

upload.definition = {
    methods: ["post"],
    url: '/kiosk/video',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
upload.url = (options?: RouteQueryOptions) => {
    return upload.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
upload.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
const uploadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upload.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::upload
* @see app/Http/Controllers/Kiosk/SessionController.php:335
* @route '/kiosk/video'
*/
uploadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: upload.url(options),
    method: 'post',
})

upload.form = uploadForm

const video = {
    upload: Object.assign(upload, upload),
}

export default video
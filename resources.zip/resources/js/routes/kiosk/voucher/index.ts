import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Kiosk\SessionController::apply
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
export const apply = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: apply.url(options),
    method: 'post',
})

apply.definition = {
    methods: ["post"],
    url: '/kiosk/voucher/apply',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Kiosk\SessionController::apply
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
apply.url = (options?: RouteQueryOptions) => {
    return apply.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Kiosk\SessionController::apply
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
apply.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: apply.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::apply
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
const applyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: apply.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Kiosk\SessionController::apply
* @see app/Http/Controllers/Kiosk/SessionController.php:222
* @route '/kiosk/voucher/apply'
*/
applyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: apply.url(options),
    method: 'post',
})

apply.form = applyForm

const voucher = {
    apply: Object.assign(apply, apply),
}

export default voucher
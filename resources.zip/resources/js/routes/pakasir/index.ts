import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
export const notify = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: notify.url(options),
    method: 'post',
})

notify.definition = {
    methods: ["post"],
    url: '/api/booth/pakasir/callback',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
notify.url = (options?: RouteQueryOptions) => {
    return notify.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
notify.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: notify.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
const notifyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: notify.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\PakasirNotifyController::__invoke
* @see app/Http/Controllers/PakasirNotifyController.php:30
* @route '/api/booth/pakasir/callback'
*/
notifyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: notify.url(options),
    method: 'post',
})

notify.form = notifyForm

const pakasir = {
    notify: Object.assign(notify, notify),
}

export default pakasir